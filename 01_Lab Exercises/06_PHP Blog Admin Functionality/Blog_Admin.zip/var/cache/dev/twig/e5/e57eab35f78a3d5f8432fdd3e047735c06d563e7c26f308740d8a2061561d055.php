<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_4adb43a4b68ef267ef162fda6125dee970a2642a16f39421babad22034f79b04 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f1e68b11c79334477b713c70f99f479a1e8e4968e028c75802028b3ad03944d3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f1e68b11c79334477b713c70f99f479a1e8e4968e028c75802028b3ad03944d3->enter($__internal_f1e68b11c79334477b713c70f99f479a1e8e4968e028c75802028b3ad03944d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_f1e68b11c79334477b713c70f99f479a1e8e4968e028c75802028b3ad03944d3->leave($__internal_f1e68b11c79334477b713c70f99f479a1e8e4968e028c75802028b3ad03944d3_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
    }
}
