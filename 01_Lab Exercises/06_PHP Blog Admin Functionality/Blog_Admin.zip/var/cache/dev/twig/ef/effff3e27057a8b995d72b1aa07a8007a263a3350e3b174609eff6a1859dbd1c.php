<?php

/* @Twig/Exception/exception_full.html.twig */
class __TwigTemplate_9abca970b5ac01b5e4e1300536630af25b56014f5bc8e7c615a7da81037d7d2a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@Twig/Exception/exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3c3419a8b803d07c463acadad36bcd5b5c3b4e4221600aecd6c096cff088a825 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3c3419a8b803d07c463acadad36bcd5b5c3b4e4221600aecd6c096cff088a825->enter($__internal_3c3419a8b803d07c463acadad36bcd5b5c3b4e4221600aecd6c096cff088a825_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3c3419a8b803d07c463acadad36bcd5b5c3b4e4221600aecd6c096cff088a825->leave($__internal_3c3419a8b803d07c463acadad36bcd5b5c3b4e4221600aecd6c096cff088a825_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_058f09b8f4b2385657b9a08c763c9f6b95ad8422d18f74a2a101419f5cf54a01 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_058f09b8f4b2385657b9a08c763c9f6b95ad8422d18f74a2a101419f5cf54a01->enter($__internal_058f09b8f4b2385657b9a08c763c9f6b95ad8422d18f74a2a101419f5cf54a01_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpFoundationExtension')->generateAbsoluteUrl($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_058f09b8f4b2385657b9a08c763c9f6b95ad8422d18f74a2a101419f5cf54a01->leave($__internal_058f09b8f4b2385657b9a08c763c9f6b95ad8422d18f74a2a101419f5cf54a01_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_29fcb4be6e014eec351e7fe326098ed411fe7370d0d8ea75ff849c6cd03cbb67 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_29fcb4be6e014eec351e7fe326098ed411fe7370d0d8ea75ff849c6cd03cbb67->enter($__internal_29fcb4be6e014eec351e7fe326098ed411fe7370d0d8ea75ff849c6cd03cbb67_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_29fcb4be6e014eec351e7fe326098ed411fe7370d0d8ea75ff849c6cd03cbb67->leave($__internal_29fcb4be6e014eec351e7fe326098ed411fe7370d0d8ea75ff849c6cd03cbb67_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_fd059783010efc81dd02e76823b08a77a0e0d0b2de308f92e7c52937a346c023 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fd059783010efc81dd02e76823b08a77a0e0d0b2de308f92e7c52937a346c023->enter($__internal_fd059783010efc81dd02e76823b08a77a0e0d0b2de308f92e7c52937a346c023_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "@Twig/Exception/exception_full.html.twig", 12)->display($context);
        
        $__internal_fd059783010efc81dd02e76823b08a77a0e0d0b2de308f92e7c52937a346c023->leave($__internal_fd059783010efc81dd02e76823b08a77a0e0d0b2de308f92e7c52937a346c023_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 12,  72 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@Twig/layout.html.twig' %}

{% block head %}
    <link href=\"{{ absolute_url(asset('bundles/framework/css/exception.css')) }}\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include '@Twig/Exception/exception.html.twig' %}
{% endblock %}
";
    }
}
