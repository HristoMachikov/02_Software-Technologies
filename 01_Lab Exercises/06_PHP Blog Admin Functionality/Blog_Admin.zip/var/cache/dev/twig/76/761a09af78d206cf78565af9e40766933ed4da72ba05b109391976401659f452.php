<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_3e147a6632136fb09da8d085fe2603d9538addf06ffc0a17739bf3245227a91b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c15a6e19be1ea27e3959821b48cd9d5523fc56335ba688e6d69fdceebb779770 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c15a6e19be1ea27e3959821b48cd9d5523fc56335ba688e6d69fdceebb779770->enter($__internal_c15a6e19be1ea27e3959821b48cd9d5523fc56335ba688e6d69fdceebb779770_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_c15a6e19be1ea27e3959821b48cd9d5523fc56335ba688e6d69fdceebb779770->leave($__internal_c15a6e19be1ea27e3959821b48cd9d5523fc56335ba688e6d69fdceebb779770_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    public function getSource()
    {
        return "";
    }
}
