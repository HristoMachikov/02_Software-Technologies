<?php

/* user/profile.html.twig */
class __TwigTemplate_1d7e487767a0433bf4162e79fa2b8e4cf9095278778b9e69d2a12d1cc7b8ae76 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "user/profile.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_24664ae4836464b49c0154574503250a9fc4add172da5c01728e73bcdd321dc5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_24664ae4836464b49c0154574503250a9fc4add172da5c01728e73bcdd321dc5->enter($__internal_24664ae4836464b49c0154574503250a9fc4add172da5c01728e73bcdd321dc5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/profile.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_24664ae4836464b49c0154574503250a9fc4add172da5c01728e73bcdd321dc5->leave($__internal_24664ae4836464b49c0154574503250a9fc4add172da5c01728e73bcdd321dc5_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_a7ee5f3d7e748919ba813bf47702491a4e229026aa18b2eeed18c41283c76b4b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a7ee5f3d7e748919ba813bf47702491a4e229026aa18b2eeed18c41283c76b4b->enter($__internal_a7ee5f3d7e748919ba813bf47702491a4e229026aa18b2eeed18c41283c76b4b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "profile";
        
        $__internal_a7ee5f3d7e748919ba813bf47702491a4e229026aa18b2eeed18c41283c76b4b->leave($__internal_a7ee5f3d7e748919ba813bf47702491a4e229026aa18b2eeed18c41283c76b4b_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_e4e7fd15585a3727b195266ace2cd6b79e505ab64c544af62d386ce533d38e05 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e4e7fd15585a3727b195266ace2cd6b79e505ab64c544af62d386ce533d38e05->enter($__internal_e4e7fd15585a3727b195266ace2cd6b79e505ab64c544af62d386ce533d38e05_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <div>
        ";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "email", array()), "html", null, true);
        echo "
        <br>
        ";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "fullName", array()), "html", null, true);
        echo "
    </div>
";
        
        $__internal_e4e7fd15585a3727b195266ace2cd6b79e505ab64c544af62d386ce533d38e05->leave($__internal_e4e7fd15585a3727b195266ace2cd6b79e505ab64c544af62d386ce533d38e05_prof);

    }

    public function getTemplateName()
    {
        return "user/profile.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  61 => 9,  56 => 7,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends 'base.html.twig' %}

{% block body_id 'profile' %}

{% block main %}
    <div>
        {{ user.email }}
        <br>
        {{ user.fullName }}
    </div>
{% endblock %}
";
    }
}
