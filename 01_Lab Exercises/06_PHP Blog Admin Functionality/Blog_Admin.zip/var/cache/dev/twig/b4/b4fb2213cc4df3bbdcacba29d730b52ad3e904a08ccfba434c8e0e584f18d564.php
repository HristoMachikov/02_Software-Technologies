<?php

/* user/profile.html.twig */
class __TwigTemplate_7053ac66b6e7fb06b76760895cb9e932722fb10b6222bcb3b5447a21dfbde612 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "user/profile.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b2dff4297c7c59d87943d471c559a84cc468912b6038332fc1015604c257541f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b2dff4297c7c59d87943d471c559a84cc468912b6038332fc1015604c257541f->enter($__internal_b2dff4297c7c59d87943d471c559a84cc468912b6038332fc1015604c257541f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/profile.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b2dff4297c7c59d87943d471c559a84cc468912b6038332fc1015604c257541f->leave($__internal_b2dff4297c7c59d87943d471c559a84cc468912b6038332fc1015604c257541f_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_ea5313ebdea7392552e4275a80a279af22746e611ab41284a5d47b5d30b0262c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ea5313ebdea7392552e4275a80a279af22746e611ab41284a5d47b5d30b0262c->enter($__internal_ea5313ebdea7392552e4275a80a279af22746e611ab41284a5d47b5d30b0262c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "profile";
        
        $__internal_ea5313ebdea7392552e4275a80a279af22746e611ab41284a5d47b5d30b0262c->leave($__internal_ea5313ebdea7392552e4275a80a279af22746e611ab41284a5d47b5d30b0262c_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_da285cf493e97355c26213b98ea00fc7961b9a486910e37732b321ce44af1e40 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_da285cf493e97355c26213b98ea00fc7961b9a486910e37732b321ce44af1e40->enter($__internal_da285cf493e97355c26213b98ea00fc7961b9a486910e37732b321ce44af1e40_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <div>
        ";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "email", array()), "html", null, true);
        echo "
        <br>
        ";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "fullName", array()), "html", null, true);
        echo "
    </div>
";
        
        $__internal_da285cf493e97355c26213b98ea00fc7961b9a486910e37732b321ce44af1e40->leave($__internal_da285cf493e97355c26213b98ea00fc7961b9a486910e37732b321ce44af1e40_prof);

    }

    public function getTemplateName()
    {
        return "user/profile.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  61 => 9,  56 => 7,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends 'base.html.twig' %}

{% block body_id 'profile' %}

{% block main %}
    <div>
        {{ user.email }}
        <br>
        {{ user.fullName }}
    </div>
{% endblock %}
";
    }
}
