<?php

/* @Framework/Form/attributes.html.php */
class __TwigTemplate_c2ddc05a8a330449e908a6c06afd3dc7fc054e0553f9c9cc39df5df888306a85 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7d6d901d9eb13c31884f1ae5288ee5b40b8bf68dcf9e2a3749ba69c36074c49b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7d6d901d9eb13c31884f1ae5288ee5b40b8bf68dcf9e2a3749ba69c36074c49b->enter($__internal_7d6d901d9eb13c31884f1ae5288ee5b40b8bf68dcf9e2a3749ba69c36074c49b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
";
        
        $__internal_7d6d901d9eb13c31884f1ae5288ee5b40b8bf68dcf9e2a3749ba69c36074c49b->leave($__internal_7d6d901d9eb13c31884f1ae5288ee5b40b8bf68dcf9e2a3749ba69c36074c49b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
";
    }
}
