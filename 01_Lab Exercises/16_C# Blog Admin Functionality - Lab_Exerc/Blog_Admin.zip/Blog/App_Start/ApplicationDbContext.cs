﻿namespace Blog
{
    internal class ApplicationDbContext
    {
    }
}